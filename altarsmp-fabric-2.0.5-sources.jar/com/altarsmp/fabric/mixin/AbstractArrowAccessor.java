package com.altarsmp.fabric.mixin;

import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(AbstractArrow.class)
public interface AbstractArrowAccessor {

    @Invoker("setPierceLevel")
    void altarsmp$setPierceLevel(byte level);

    @Accessor("baseDamage")
    double altarsmp$getBaseDamage();
}
